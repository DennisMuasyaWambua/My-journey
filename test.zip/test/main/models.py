from django.db import models


class Property(models.Model):
    PropertyId = models.AutoField(primary_key=True, unique=True)
    PropertyName = models.CharField(max_length=30)
    Capacity = models.IntegerField(null=False)

    pass


class LandLord(models.Model):
    LandLordId = models.AutoField(primary_key=True, unique=True)
    fName = models.CharField(max_length=30)
    lName = models.CharField(max_length=30)
    PropertyId = models.OneToOneField(Property, on_delete=models.CASCADE)


class Occupant(models.Model):
    OccupantId = models.AutoField(primary_key=True, unique=True)
    BlockNumber = models.CharField(max_length=4)
    HouseNumber = models.IntegerField()
    OCCUPATION_TYPE = (
        ('Ten', 'Tenant'),
        ('Self', 'Self Owned'),
    )
    occupationType = models.CharField(choices=OCCUPATION_TYPE, max_length=50)
    landlord = models.ForeignKey(LandLord, on_delete=models.CASCADE)

    pass


class Payment(models.Model):
    PaymentId = models.AutoField(primary_key=True, unique=True)
    PaymentDate = models.DateField(auto_now=True)
    PaymentTime = models.TimeField(auto_now=True)
    Amount = models.IntegerField(null=False)
    Occupant = models.OneToOneField(Occupant, on_delete=models.CASCADE)


class Billing(models.Model):
    BillId = models.AutoField(primary_key=True)
    Occupant = models.OneToOneField(Occupant, on_delete=models.CASCADE)
    Payment = models.OneToOneField(Payment, on_delete=models.CASCADE)
    Balance = models.DecimalField(null=True, decimal_places=4, max_digits=100)
    BillDate = models.DateField(auto_now=True)
    BillTime = models.TimeField(auto_now=True)


