from django.shortcuts import render


def home(response):
    return render(response, 'main/index.html')

def aboutus(response):
    return render(response, 'main/aboutus.html')
